package config.fr

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class config800 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_config800)

    }
}