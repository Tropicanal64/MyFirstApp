package config.fr

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main2.*

class MainActivity2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val configa800 = Intent(this, config800::class.java)
        val configa1000 = Intent(this, config1000::class.java)
        val configa1500 = Intent(this, config1500::class.java)
        val configa2000 = Intent(this, config2000::class.java)

        btnretour.setOnClickListener{
            this.finish()
        }

        config800btn.setOnClickListener{
            startActivity(configa800)
        }
        config1000btn.setOnClickListener{
            startActivity(configa1000)
        }
        config1500btn.setOnClickListener{
            startActivity(configa1500)
        }
        config2000btn.setOnClickListener{
            startActivity(configa2000)
        }

    }
}
