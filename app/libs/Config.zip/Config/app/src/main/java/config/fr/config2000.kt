package config.fr

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class config2000 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_config2000)
    }
}
