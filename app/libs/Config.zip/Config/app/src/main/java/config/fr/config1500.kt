package config.fr

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class config1500 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_config1500)
    }
}
